package com.mababapay.paydemo;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaydemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
