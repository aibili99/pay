package com.mababapay.paydemo.utils;

import com.mababapay.paydemo.modelData;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.springframework.web.client.RestTemplate;
import sun.net.www.http.HttpClient;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class common {

    public static String SetMoneySign(String orderid, String ssPrice) {
        String thissign = Md5V(Md5V(orderid + ssPrice) + modelData.AppId + modelData.AppKey);
        return thissign;
    }

    //验证sign
    public static boolean SignCheck(String sign, String orderid) {
        String mysign = common.Md5V(common.Md5V(orderid) + modelData.AppKey);
        if (sign.equals(mysign)) {
            return true;
        }
        return false;
    }

    public static String Md5V(String str) {
        try {
            byte[] bytesOfMessage = str.getBytes("UTF-8");
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] thedigest = md.digest(bytesOfMessage);
            String md5Result = ByteUtil.parseByte2HexStr(thedigest).toLowerCase();
            //System.out.println(str + ":" + md5Result);
            return md5Result;
        } catch (java.io.UnsupportedEncodingException exception) {
            return null;

        } catch (java.security.NoSuchAlgorithmException exception) {
            return null;
        }

    }

    public static String GetWebRequestPostJson(String url, String postData) {
        String result = "";
        HttpPost post = new HttpPost(url);
        try {
            CloseableHttpClient httpClient = HttpClients.createDefault();

            post.setHeader("Content-Type", "application/json;charset=utf-8");

            StringEntity postingString = new StringEntity(postData, "utf-8");
            post.setEntity(postingString);
            HttpResponse response = httpClient.execute(post);

            InputStream in = response.getEntity().getContent();
            BufferedReader br = new BufferedReader(new InputStreamReader(in, "utf-8"));
            StringBuilder strber = new StringBuilder();
            String line = null;
            while ((line = br.readLine()) != null) {
                strber.append(line + '\n');
            }
            br.close();
            in.close();
            result = strber.toString();
            if (response.getStatusLine().getStatusCode() != HttpStatus.SC_OK) {
                result = "服务器异常";
            }
        } catch (Exception e) {
            System.out.println("请求异常");
            throw new RuntimeException(e);
        } finally {
            post.abort();
        }
        return result;
    }

}
