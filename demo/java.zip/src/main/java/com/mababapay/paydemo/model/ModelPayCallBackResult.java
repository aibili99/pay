package com.mababapay.paydemo.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

public class ModelPayCallBackResult {
    public String Created_at;
    public String Updated_at;
    public String Pay_status;
    public Integer Id;

    @JsonProperty("orderId")
    public String Order_id;
    @JsonProperty("orderType")
    public String Order_type;
    @JsonProperty("orderPrice")
    public Float Order_price;
    @JsonProperty("orderName")
    public String Order_name;
    @JsonProperty("extension")
    public String Extension;
    @JsonProperty("redirectUrl")
    public String Redirect_url;
    @JsonProperty("qrUrl")
    public String Qr_url;
    @JsonProperty("qrPrice")
    public Float Qr_price;
}
