package com.mababapay.paydemo;

import com.mababapay.paydemo.model.ResponseBodyModel;
import com.mababapay.paydemo.utils.common;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

@RestController
public class OrderCallBack {

    @RequestMapping("check")
    public ResponseBodyModel check() {

        ResponseBodyModel body = new ResponseBodyModel();
        body.Status = 500;
        if (modelData.IsSuccess) {
            body.Status = 200;
            body.Message = "支付成功";
        }
        return body;
    }

    @RequestMapping("callback")
    public ResponseBodyModel Callback(HttpServletRequest request) {

        ResponseBodyModel body = new ResponseBodyModel();
        body.Status = 500;

        String orderid = request.getParameter("orderid");
        String money = request.getParameter("money");
        String sign = request.getParameter("sign");

        boolean b = common.SignCheck(sign, orderid);
        if (!b) {
            body.Message = "签名失败";
            return body;
        }

        if (modelData.OrderId.equals(orderid)) {
            modelData.IsSuccess = true;
        }

        body.Status = 200;
        body.Message = "成功";
        return body;

    }
}
