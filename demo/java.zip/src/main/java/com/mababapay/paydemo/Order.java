package com.mababapay.paydemo;

import com.mababapay.paydemo.model.ModelPayCallBackResult;
import com.mababapay.paydemo.model.ResponseBodyModel;
import com.mababapay.paydemo.utils.common;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.text.DecimalFormat;
import java.util.Random;
import java.util.UUID;

@Controller
public class Order {

    @RequestMapping("/")
    public ModelAndView CreateOrder(Model model) {

        ModelAndView mv = new ModelAndView();
        mv.setViewName("/pay.html");

        ServiceOrder s = new ServiceOrder();

        UUID uuid = UUID.randomUUID();
        //订单编号
        String OrderId = uuid.toString();

        modelData.OrderId = OrderId;
        modelData.IsSuccess = false;
        //订单金额
        float OrderPrice = new Random().nextFloat() + 10;

        //一定要保留两位小数，否则签名不过关
        DecimalFormat decimalFormat = new DecimalFormat(".00");
        String p = decimalFormat.format(OrderPrice);//format 返回的是字符串
        Float pp = Float.parseFloat(p);

        //订单名称
        String OrderName = "测试订单";


        ModelPayCallBackResult result = new ModelPayCallBackResult();
        try {
            result = s.PayCreateOrder(OrderId, pp, OrderName, "alipay", "扩展信息");

        } catch (Exception ex) {
            model.addAttribute("message", "创建订单出错：" + ex.getMessage());
            return mv;
        }


        model.addAttribute("OrderId", OrderId);
        model.addAttribute("QrUrl", result.Qr_url);

        return mv;
    }


}


