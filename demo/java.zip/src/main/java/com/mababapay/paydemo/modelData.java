package com.mababapay.paydemo;

import lombok.Data;

public class modelData {

    //码叭叭支付平台地址
    //public static String MababaPayUrl = "http://api.mababapay.com";
    public static String MababaPayUrl = "http://localhost:61";

    //码叭叭上的AppId
    public static String AppId = "A123456789";

    //码叭叭上的秘钥
    public static String AppKey = "1234568";


    public static String OrderId = "";
    public static boolean IsSuccess = false;

}
