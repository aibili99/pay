package com.mababapay.paydemo;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mababapay.paydemo.model.MababaPostData;
import com.mababapay.paydemo.model.ModelPayCallBackErrorResult;
import com.mababapay.paydemo.model.ModelPayCallBackResult;
import com.mababapay.paydemo.utils.common;


public class ServiceOrder {


    private static ObjectMapper MAPPER = new ObjectMapper();

    //自已平台创建充值订单
    public ModelPayCallBackResult PayCreateOrder(String orderid, float price, String order_name, String paytype, String extension) throws Exception {

        ModelPayCallBackResult payData = new ModelPayCallBackResult();

        ModelPayCallBackErrorResult payResultData = new ModelPayCallBackErrorResult();


        String ssPrice = Float.toString(price);
        String sign = common.SetMoneySign(orderid, ssPrice);
        String callback = "http://localhost:8080/callback";

        String url = modelData.MababaPayUrl + "/api/v1/createorder";

        ModelPayCallBackResult postdata = new ModelPayCallBackResult();

        postdata.Redirect_url = callback;
        postdata.Order_id = orderid;
        postdata.Order_type = paytype;
        postdata.Order_price = price;
        postdata.Order_name = order_name;
        postdata.Extension = extension;

        MababaPostData alipayPost = new MababaPostData();
        alipayPost.Sign = sign;
        alipayPost.AppKey = modelData.AppKey;
        alipayPost.AppId = modelData.AppId;
        alipayPost.Data = postdata;

        //var data = "order_id=" + orderid + "&order_type=" + paytype + "&order_price=" + price + "&order_name=" + order_name + "&sign=" + sign + "&redirect_url=" + callback + "&extension=" + extension;
        String data = MAPPER.writeValueAsString(alipayPost);
        String resultReq = common.GetWebRequestPostJson(url, data);

        if (resultReq.contains("404")) {
            throw new Exception("404错误");
        } else {

            payResultData = MAPPER.readValue(resultReq, ModelPayCallBackErrorResult.class);

            if (payResultData.Status != 200) {
                throw new Exception(payResultData.Message);
            } else {
                payData = payResultData.Data;
            }
        }

        return payData;
    }



}
