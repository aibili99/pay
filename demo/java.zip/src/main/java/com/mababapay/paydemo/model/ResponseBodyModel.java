package com.mababapay.paydemo.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ResponseBodyModel {

    @JsonProperty("status")
    public Integer Status;
    @JsonProperty("message")
    public String Message;
}
