package com.mababapay.paydemo.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;


public class ModelPayCallBackErrorResult {

    @JsonProperty("status")
    public Integer Status;
    @JsonProperty("message")
    public String Message;

    @JsonProperty("data")
    public ModelPayCallBackResult Data;
}
