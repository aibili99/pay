package com.mababapay.paydemo.model;

public class MababaPostData {

    public ModelPayCallBackResult Data;
    public String Sign;
    public String AppId;
    public String AppKey;

}
