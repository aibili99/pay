package utils

import (
	"bytes"
	"io/ioutil"
	"net/http"
)


//post提交参数
func GetWebRequestPostJson(url string, bytesData []byte) (result string, err error) {

	if len(url) < 10 {
		if err != nil {
			return "", NewError(500, "请求地址不正确")
		}
	}
	postdata := bytes.NewReader(bytesData)
	resp, err := http.Post(url, "application/json;charset=UTF-8", postdata)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()
	body, err := ioutil.ReadAll(resp.Body)

	if err != nil {
		return "", err
	}
	result = string(body)

	return

}