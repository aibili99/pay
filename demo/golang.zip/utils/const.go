package utils

import uuid "github.com/satori/go.uuid"

type ResponseBodyModel struct {
	Status  int         `json:"status"`
	Message string      `json:"message"`
	Data    interface{} `json:"data"`
}

func NewResponseBodyModel() *ResponseBodyModel {
	r := new(ResponseBodyModel)
	r.Status = 501
	r.Message = "未定义错误"
	return r
}


func Guid() string {
	u1 := uuid.NewV4()
	return u1.String()
}

