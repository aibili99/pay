package utils

import (
	"crypto/md5"
	"encoding/hex"
	"mababapaydemo/model"
)

func Md5V(str string) string {
	h := md5.New()
	h.Write([]byte(str))
	return hex.EncodeToString(h.Sum(nil))
}

func SetMoneySign(orderid string, ssPrice string) (string) {
	thissign := Md5V(Md5V(orderid+ssPrice) + model.AppId + model.AppKey)
	return thissign
}
