package router

import (
	"github.com/gin-gonic/gin"
	"mababapaydemo/view"
)

var R *gin.Engine

func InitRouter() {
	R = gin.Default()

	R.GET("/", view.Index)
	R.GET("/callback", view.CallBack)

}
