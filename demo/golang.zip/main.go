package main

import (
	"mababapaydemo/router"
)

func main() {

	router.InitRouter()
	router.R.Run(":66")
}
