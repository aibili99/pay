package service

import (
	"encoding/json"
	"github.com/gin-gonic/gin"
	"mababapaydemo/model"
	"mababapaydemo/utils"
	"strconv"
	"strings"
)

type ServiceOrder struct {
}

//自已平台创建充值订单
func (p *ServiceOrder) PayCreateOrder(gc *gin.Context, orderid string, price float64, order_name string, paytype string, extension string) (paydata model.ModelPayCallBackResult, err error) {

	payResultData := model.ModelPayCallBackErrorResult{}

	ssPrice := strconv.FormatFloat(price, 'f', 2, 64)
	var sign = utils.SetMoneySign(orderid, ssPrice)
	//var callback = "http://localhost:8080/api/v1/moneyinpaycallback"
	var callback = "http://localhost:66/callback"

	//var url = "http://192.168.4.200:7001/api/order"
	var url = model.MababaPayUrl + "/api/v1/createorder"

	postdata := model.ModelPayCallBackResult{}
	postdata.Redirect_url = callback
	postdata.Order_id = orderid
	postdata.Order_type = paytype
	postdata.Order_price = price
	postdata.Order_name = order_name
	postdata.Extension = extension

	alipayPost := model.MababaPostData{}
	alipayPost.Sign = sign
	alipayPost.AppKey = model.AppKey
	alipayPost.AppId = model.AppId
	alipayPost.Data = postdata

	//var data = "order_id=" + orderid + "&order_type=" + paytype + "&order_price=" + price + "&order_name=" + order_name + "&sign=" + sign + "&redirect_url=" + callback + "&extension=" + extension;
	data, err := json.Marshal(alipayPost)
	resultReq, err := utils.GetWebRequestPostJson(url, data)

	if (err != nil) {
		return
	} else if (strings.Contains(resultReq, "404")) {
		err = utils.NewError(500, resultReq)
		return
	} else {
		//var payData midModel.ModelPayCallBackResult
		err = json.Unmarshal([]byte(resultReq), &payResultData)
		if err != nil {
			return
		}
		if (payResultData.Status != 200) {
			err = utils.NewError(500, payResultData.Message)
		} else {
			paydata = payResultData.Data
		}
	}

	return
}

//验证sign
func (p *ServiceOrder) SignCheck(sign string, orderid string) (err error) {

	var mysign = utils.Md5V(utils.Md5V(orderid) + model.AppKey)

	if (sign != mysign) {
		err = utils.NewError(500, "订单检验不正确")
	}

	return
}
