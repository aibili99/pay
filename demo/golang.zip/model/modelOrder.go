package model

//码叭叭支付平台地址
var MababaPayUrl = "http://localhost:61"

//码叭叭上的AppId
var AppId = "app740dc12d-9384-4ccd-95c0-f0a2cc491eb4"

//码叭叭上的秘钥
var AppKey = "5622876310"

type ModelPayCallBackErrorResult struct {
	Status  int                    `json:"status"`
	Message string                 `json:"message"`
	Data    ModelPayCallBackResult `json:"data"`
}

//支付中介平台，创建订单返回消息体
type ModelPayCallBackResult struct {
	Created_at   string  `json:"createdAt"`
	Updated_at   string  `json:"updatedAt"`
	Pay_status   string  `json:"payStatus"`
	Id           int     `json:"id"`
	Order_id     string  `json:"orderId"`
	Order_type   string  `json:"orderType"`
	Order_price  float64 `json:"orderPrice"`
	Order_name   string  `json:"orderName"`
	Extension    string  `json:"extension"`
	Redirect_url string  `json:"redirectUrl"`
	Qr_url       string  `json:"qrUrl"`
	Qr_price     float64 `json:"qrPrice"`
}

type MababaPostData struct {
	Data   ModelPayCallBackResult
	Sign   string `json:"sign"`
	AppId  string
	AppKey string
}
