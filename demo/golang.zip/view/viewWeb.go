package view

import (
	"github.com/gin-gonic/gin"
	"mababapaydemo/service"
	"mababapaydemo/utils"
	"math/rand"
	"net/http"
	"strconv"
)

//首页，创建订单
func Index(gc *gin.Context) {

	s := service.ServiceOrder{}

	//订单编号
	OrderId := utils.Guid()
	//订单金额
	OrderPrice := rand.Float64()
	OrderPrice = OrderPrice + 1000
	ssPrice := strconv.FormatFloat(OrderPrice, 'f', 2, 64)
	p, _ := strconv.ParseFloat(ssPrice, 64)
	//订单名称
	OrderName := "测试订单"

	paydata, err2 := s.PayCreateOrder(gc, OrderId, p, OrderName, "alipay", "扩展信息")
	if (err2 != nil) {
		gc.String(200, "生成支付宝二码维出错"+err2.Error())
		return
	}

	gc.String(200, "生成随机订单："+OrderId+"<br>二维码地址："+paydata.Qr_url)

}

//订单回调
func CallBack(gc *gin.Context) {

	res := utils.NewResponseBodyModel()

	orderid := gc.DefaultQuery("orderid", "")
	AlipayMoney := gc.DefaultQuery("money", "")
	sign := gc.DefaultQuery("sign", "")

	if (orderid == "" || AlipayMoney == "" || sign == "") {
		res.Message = "订单号不正确"
		gc.JSON(http.StatusOK, res)
		gc.Abort()
		return
	}

	sers := service.ServiceOrder{}

	err := sers.SignCheck(sign, orderid)
	if (err != nil) {
		res.Message = err.Error()
		gc.JSON(http.StatusOK, res)
		gc.Abort()
		return
	}
	//返回值
	res.Status = 200
	res.Message = "订单成功!"
	gc.JSON(200, res)
}
